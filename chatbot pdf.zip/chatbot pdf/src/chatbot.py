
## Insights
- Embeddings permitem buscar informações relevantes sem depender de conhecimento prévio do modelo.
- Possibilidade de expandir para mais PDFs, criar interface web ou integrar com APIs externas.
