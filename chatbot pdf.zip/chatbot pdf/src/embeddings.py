# embeddings.py

import os
from openai import OpenAI
from PyPDF2 import PdfReader

client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

def gerar_embedding(texto, modelo="text-embedding-3-small"):
    """
    Gera embedding para um texto usando o modelo especificado.
    
    Args:
        texto (str): O texto para gerar embedding.
        modelo (str): Modelo de embeddings a ser usado.
    
    Returns:
        list[float]: Vetor de embedding.
    """
    try:
        resposta = client.embeddings.create(
            model=modelo,
            input=texto
        )
        return resposta.data[0].embedding
    except Exception as e:
        print(f"Erro ao gerar embedding: {e}")
        return None

def ler_pdf(caminho_pdf):
    """
    Lê o conteúdo de um PDF e retorna como string.
    """
    try:
        reader = PdfReader(caminho_pdf)
        texto = ""
        for pagina in reader.pages:
            texto += pagina.extract_text() + "\n"
        return texto
    except Exception as e:
        print(f"Erro ao ler PDF {caminho_pdf}: {e}")
        return ""

def salvar_embeddings(nome_arquivo, embeddings):
    """
    Salva embeddings em um arquivo .txt
    """
    try:
        with open(nome_arquivo, "w", encoding="utf-8") as f:
            for emb in embeddings:
                f.write(",".join(map(str, emb)) + "\n")
        print(f"Embeddings salvos em {nome_arquivo}")
    except Exception as e:
        print(f"Erro ao salvar embeddings: {e}")

def gerar_embeddings_de_pdfs(pasta="inputs"):
    """
    Gera embeddings de todos os PDFs em uma pasta.
    """
    embeddings = []
    arquivos = [f for f in os.listdir(pasta) if f.endswith(".pdf")]
    
    for arquivo in arquivos:
        caminho = os.path.join(pasta, arquivo)
        print(f"Lendo {arquivo}...")
        texto = ler_pdf(caminho)
        if texto:
            emb = gerar_embedding(texto)
            if emb:
                embeddings.append(emb)
    
    salvar_embeddings("embeddings.txt", embeddings)
    return embeddings

if __name__ == "__main__":
    print("Gerando embeddings de PDFs na pasta 'inputs'...")
    gerar_embeddings_de_pdfs()
